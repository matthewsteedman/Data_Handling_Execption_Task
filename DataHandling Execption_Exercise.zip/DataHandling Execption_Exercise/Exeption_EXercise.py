from tkinter import *
from tkinter import messagebox

# Tkinter login window

window = Tk()
window.title("Authentification")
window.geometry("500x200")

# created a definition and shoved another tkinter window inside
# when login is clicked it activates the second window called 'root'


def login():

    root = Tk()
    root.title("Exception Handling")
    root.geometry("500x200")

# Entry box

    txt_box_amnt = Entry(root, width=20)
    txt_box_amnt.grid(row=2, column=3)

# when a number is entered in to the entry box , the number runs through the program below and checks if its greater
    # than or less then 3000

    def trip():
        if float(txt_box_amnt.get()) >= 3000:
            messagebox.showinfo("Status Feedback", "Congratulations. You qualify to go to Malaysia")
        elif float(txt_box_amnt.get()) < 3000:
            messagebox.showinfo("Status Feedback", "Insufficient Funds!")
        '''elif (txt_box_amnt.get()) == None:
            messagebox.showinfo("Error", "Please Enter a Valid AMOUNT!")'''

#  labels and buttons

    lb_pls_ent_amnt_int_yr_acnt = Label(root, text="Please enter amount in your account")
    lb_pls_ent_amnt_int_yr_acnt.grid(row=1, column=3)

    btn_check = Button(root, text="Check Qualification", command=trip)
    btn_check.grid(row=3, column=3)

# withdraw thew window and opens up the root

    window.withdraw()

# messagebox

    messagebox.showinfo("Well Done!", "You Have Successfully Logged In!")


# labels , entry boxes and buttons for the login Tkinter program


lb_pls_ent_Lgn_dts = Label(window, text="Please enter login details")
lb_pls_ent_Lgn_dts.grid(row=1, column=3)

lb_Us = Label(window, text="Username")
lb_Us.grid(row=2, column=1)
txt_usn = Entry(window, width=20)
txt_usn.grid(row=2, column=3)

lb_pswd = Label(window, text="Password")
lb_pswd.grid(row=3, column=1)
txt_pswd = Entry(window, width=20, show='*')
txt_pswd.grid(row=3, column=3)

btn_lgn = Button(window, text="Login", command=login)
btn_lgn.grid(row=4, column=2)

window.mainloop()
