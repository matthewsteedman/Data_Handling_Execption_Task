from tkinter import *
from tkinter import messagebox
root = Tk()
root.title("Exception Handling")



txt_box_amnt = Entry(root, width=20)

def trip():
    if float(txt_box_amnt.get()) >= 3000:
        messagebox.showinfo("Status Feedback", "Congratulations. You qualify to go to Malaysia")
    elif float(txt_box_amnt.get()) < 3000:
        messagebox.showinfo("Status Feedback", "Insufficient Funds!")
    '''elif (txt_box_amnt.get()) == None:
        messagebox.showinfo("Error", "Please Enter a Valid AMOUNT!")'''


lb_pls_ent_amnt_int_yr_acnt = Label(root, text="Please enter amount in your account").grid()
txt_box_amnt.grid()
btn_check = Button(root, text="Check Qualification", command=trip).grid()


root.mainloop()